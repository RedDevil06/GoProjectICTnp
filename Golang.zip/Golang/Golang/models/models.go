package models

import "time"

// User represents the 'users' table.
type User struct {
	FirstName        string // Not null
	LastName         string // Not null
	MobileNumber     string // Not null
	Email            string // Not null
	PasswordHash     string // Not null
	DriverLicenseNum string
	CarPlateNum      string
	UserType         string // Enum: 'passenger', 'car_owner', Not null
}

// Trip represents the 'trips' table.
type Trip struct {
	ID                 int    // Primary key, auto-incremented by the database
	CarOwnerEmail      string // Not null
	PickupLocation     string // Not null
	AltPickupLocations string
	StartTravelingTime time.Time // Not null
	DestinationAddress string    // Not null
	AvailableSeats     int       // Not null
	TripStatus         string    // Enum: 'published', 'in-progress', 'completed', 'canceled', Not null
	ScheduledStartTime time.Time
}

// Enrollment represents the 'enrollments' table.
type Enrollment struct {
	ID             int       // Primary key, auto-incremented by the database
	TripID         int       // Not null
	PassengerEmail string    // Not null
	EnrollmentDate time.Time // Default: CURRENT_TIMESTAMP
}
