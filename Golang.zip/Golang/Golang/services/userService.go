package services

import (
	initializers "GOLANG/Initializers"
	"GOLANG/models"
	"fmt"
)

func CreateUser(user models.User) (bool, error) {
	query := `
	INSERT INTO users (first_name, last_name, mobile_number, email, password_hash)
	VALUES (?, ?, ?, ?, ?)
`
	// this will crete the user and insert the specific credentials
	// Execute the raw SQL query with the values
	err := initializers.DB.Exec(query, user.FirstName, user.LastName, user.MobileNumber, user.Email, user.PasswordHash).Error
	// this will execute the query
	if err != nil {
		return false, err
	}
	return true, err

}
func UpdateUser(user models.User) (bool, error) {
	query := `
	UPDATE users
	SET
		driver_license_number = ?,
		car_plate_number = ?,
		user_type = ?
	WHERE
		email = ?
`
	// this update the query
	// Execute the raw SQL query with the values
	err := initializers.DB.Exec(query, user.DriverLicenseNum, user.CarPlateNum, user.UserType, user.Email).Error

	if err != nil {
		return false, err
	}
	return true, err

}

func Checkuser(user models.User) (int, error) {
	var count int
	query := "SELECT COUNT(*) FROM users WHERE email = ? and password_hash = ?"
	err := initializers.DB.Raw(query, user.Email, user.PasswordHash).Count(&count).Error

	if err != nil {
		return 0, err
	}

	if count > 0 {
		fmt.Println(count)
		return count, nil
	}
	return 0, nil

}

//hashed_password
