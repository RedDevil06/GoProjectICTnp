package services

import (
	initializers "GOLANG/Initializers"
	"GOLANG/models"
	"fmt"
	"time"
)

func CreateTrip(trip models.Trip) (bool, error) {
	//query fot creating the trip and inserting into the databse
	query := `
INSERT INTO trips (
    car_owner_email,
    pickup_location,
    alt_pickup_locations,
    start_traveling_time,
    destination_address,
    available_seats,
    trip_status,
    scheduled_start_time
) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
`
	// Execute the raw SQL query with the values
	err := initializers.DB.Debug().Exec(query, trip.CarOwnerEmail, trip.PickupLocation, trip.AltPickupLocations, trip.StartTravelingTime, trip.DestinationAddress, trip.AvailableSeats, "published", "2022-12-22 12:22:22").Error
	// "2006-01-02 15:04:05"
	if err != nil {
		return false, err
	}
	return true, err

}

func CreateEnrollment(enrollment models.Enrollment) (bool, error) {

	var trip models.Trip                                          // this is trip struct
	err1 := initializers.DB.First(&trip, enrollment.TripID).Error // its fetches the first row foudn on tripid

	if err1 != nil {
		return false, err1
	}

	fmt.Println(trip.AvailableSeats) //prints the avaliable seats for debugiing
	if trip.AvailableSeats > 0 {
		query1 := `
			INSERT INTO enrollments (trip_id, passenger_email)
			VALUES (?, ?)
		`
		// this query checks if the seats are avalible or not
		err := initializers.DB.Exec(query1, enrollment.TripID, enrollment.PassengerEmail).Error

		if err != nil {
			return false, err
		}
		// this will update the avalible seats to -1 if its there
		query2 := `
	UPDATE trips
	SET
		available_seats = ?
	WHERE
		id = ?
`
		// Execute the raw SQL query with the values
		err2 := initializers.DB.Exec(query2, trip.AvailableSeats-1, enrollment.TripID).Error

		if err2 != nil {
			return false, err2
		}
	}

	return true, nil

}

func DeleteTrip(trip models.Trip) (bool, error) {

	//deletes the trip if its 30 minutes remianing
	thirtyMinutesAgo := time.Now().Add(-30 * time.Minute)
	formattedTime := thirtyMinutesAgo.Format("2006-01-02 15:04:05")

	type TimeDifferenceResult struct {
		TimeDifference int64 `gorm:"column:time_difference"`
	}
	// this will insert hte time to delete the trip

	var result TimeDifferenceResult
	err := initializers.DB.Raw("SELECT TIMESTAMPDIFF(MINUTE, start_traveling_time, ?) AS time_difference FROM trips WHERE id=?", formattedTime, trip.ID).Scan(&result).Error
	if err != nil {
		return false, err
	}

	// Access the time difference from the result struct.
	timeDifference := result.TimeDifference
	fmt.Println(timeDifference)
	if timeDifference >= 30 {
		err := initializers.DB.Model(&models.Trip{}).Where("id = ? ", trip.ID).Update("trip_status", "canceled").Error
		//insert the trip canceld if there a differnce of 30 minutes
		if err != nil {
			return false, err
		}

	}
	return true, nil
}

func AllTrips() ([]models.Trip, error) {

	var trips []models.Trip
	err := initializers.DB.Find(&trips).Error
	// this query finds the  all trips and return the list of it

	if err != nil {
		return nil, err
	}
	return trips, nil
}

func MyTrips(trip models.Trip) ([]models.Trip, error) {
	// this will fetch only the loggedin user trip.
	var trips []models.Trip
	err := initializers.DB.Where("car_owner_email = ?", trip.CarOwnerEmail).Find(&trips).Error

	if err != nil {
		return nil, err
	}
	return trips, nil
}
