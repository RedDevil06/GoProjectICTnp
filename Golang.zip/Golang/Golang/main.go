package main

import (
	initializers "GOLANG/Initializers"
	"GOLANG/controllers"
	"GOLANG/models"
	"bytes"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"time"

	"github.com/gorilla/mux"
)

func init() {
	initializers.InitDB()
}

func main() {
	var userEmail = ""
	var userType = 0
	r := mux.NewRouter()
	r.HandleFunc("/users", controllers.CreateUser).Methods("POST")
	r.HandleFunc("/checkuser", controllers.CheckUser).Methods("POST")
	r.HandleFunc("/delete", controllers.DeleteTrip).Methods("POST")
	r.HandleFunc("/users", controllers.UpdateUser).Methods("PUT")
	r.HandleFunc("/trips", controllers.CreateTrip).Methods("POST")
	r.HandleFunc("/enroll", controllers.EnrollmentInTrip).Methods("POST")
	r.HandleFunc("/alltrips", controllers.AllTrips).Methods("GET")
	r.HandleFunc("/mytrips", controllers.MyTrips).Methods("POST")

	go func() {
		log.Fatal(http.ListenAndServe(":8080", r))
	}()
	fmt.Println("Welcome to the Car-Pooling Platform Console App")
	// Simulate user interaction with the console app.
	for {
		fmt.Println("\nChoose an option:")
		fmt.Println("0. Sign IN")
		fmt.Println("1. Create User Account/Sign Up")

		if userType == 1 {
			fmt.Println("3. Enroll In a trip")
		} else if userType == 2 {
			fmt.Println("2. Register a Trip")
			fmt.Println("3. Enroll In a trip")
			fmt.Println("4. Delete a Trip")
		}
		fmt.Println("5. Exit")

		var choice int
		fmt.Print("Enter your choice: ")
		_, err := fmt.Scan(&choice)
		if err != nil {
			log.Fatal(err)
		}
		if (choice == 4 || choice == 2) && userType == 1 {
			fmt.Println("Invalid Input")
			os.Exit(0)
		}
		switch choice {

		case 0:
			var user struct {
				Email        string
				PasswordHash string
			}

			fmt.Print("Enter Email: ")
			_, err = fmt.Scan(&user.Email)
			userEmail = user.Email
			if err != nil {
				fmt.Println("Error reading Email:", err)
				continue
			}

			fmt.Print("Enter Password Hash: ")
			_, err = fmt.Scan(&user.PasswordHash)
			if err != nil {
				fmt.Println("Error reading Password Hash:", err)
				continue
			}

			fmt.Print("Enter 1 for Passenger/ 2 for CarOwner: ")
			_, err = fmt.Scan(&userType)
			if err != nil {
				fmt.Println("Error reading Type:", err)
				continue
			}

			// Convert user data to JSON
			payload, err := json.Marshal(user)
			if err != nil {
				fmt.Println("Error marshaling user data to JSON:", err)
				continue
			}

			// Send a POST request to the CreateUser API
			url := "http://localhost:8080/checkuser" // Replace with the actual API endpoint URL
			resp, err := http.Post(url, "application/json", bytes.NewBuffer(payload))
			if err != nil {
				fmt.Println("Error sending HTTP request:", err)
				continue
			}

			defer resp.Body.Close()
			body, err := ioutil.ReadAll(resp.Body)
			fmt.Println(body)
			if err != nil {
				fmt.Println("Error reading response body:", err)
				return
			}

			if len(body) == 0 {
				fmt.Println("Invalid credentials")
				fmt.Println("Exiting the Car-Pooling Platform Console App.")
				os.Exit(0)
			} else {
				fmt.Println("Sign in succesfully")
				continue
			}

		case 1:
			var user struct {
				FirstName    string
				LastName     string
				MobileNumber string
				Email        string
				PasswordHash string
			}

			fmt.Print("Enter First Name: ")
			_, err := fmt.Scan(&user.FirstName)
			if err != nil {
				fmt.Println("Error reading First Name:", err)
				continue
			}

			fmt.Print("Enter Last Name: ")
			_, err = fmt.Scan(&user.LastName)
			if err != nil {
				fmt.Println("Error reading Last Name:", err)
				continue
			}

			fmt.Print("Enter Mobile Number: ")
			_, err = fmt.Scan(&user.MobileNumber)
			if err != nil {
				fmt.Println("Error reading Mobile Number:", err)
				continue
			}

			fmt.Print("Enter Email: ")
			_, err = fmt.Scan(&user.Email)
			if err != nil {
				fmt.Println("Error reading Email:", err)
				continue
			}

			fmt.Print("Enter Password Hash: ")
			_, err = fmt.Scan(&user.PasswordHash)
			if err != nil {
				fmt.Println("Error reading Password Hash:", err)
				continue
			}

			// Convert user data to JSON
			payload, err := json.Marshal(user)
			if err != nil {
				fmt.Println("Error marshaling user data to JSON:", err)
				continue
			}

			// Send a POST request to the CreateUser API
			url := "http://localhost:8080/users" // Replace with the actual API endpoint URL
			resp, err := http.Post(url, "application/json", bytes.NewBuffer(payload))
			if err != nil {
				fmt.Println("Error sending HTTP request:", err)
				continue
			}
			defer resp.Body.Close()

			// Check the response status code
			if resp.StatusCode == http.StatusOK {
				fmt.Println("User account created successfully!")
			} else {
				fmt.Println("Error creating user account. Status code:", resp.StatusCode)
			}
		case 2:
			var trip models.Trip

			fmt.Print("Enter Car Owner's Email: ")
			_, err := fmt.Scan(&trip.CarOwnerEmail)
			if err != nil {
				fmt.Println("Error reading Car Owner's Email:", err)
				continue
			}

			fmt.Print("Enter Pickup Location: ")
			_, err = fmt.Scan(&trip.PickupLocation)
			if err != nil {
				fmt.Println("Error reading Pickup Location:", err)
				continue
			}

			fmt.Print("Enter Alternate Pickup Locations (optional): ")
			_, err = fmt.Scan(&trip.AltPickupLocations)
			if err != nil {
				fmt.Println("Error reading Alternate Pickup Locations:", err)
				continue
			}

			fmt.Print("Enter Start Traveling Date (YYYY-MM-DD format): ")
			var date1 string
			_, err1 := fmt.Scan(&date1)
			if err1 != nil {
				fmt.Println("Error reading input:", err)
				return
			}

			fmt.Print("Enter Start Traveling Time ( HH:MM:SS format): ")
			var time1 string
			_, err2 := fmt.Scan(&time1)
			if err2 != nil {
				fmt.Println("Error reading input:", err)
				return
			}

			var combine string
			combine = date1 + " " + time1
			// Parse the input string into a time.Time value
			parsedTime, err := time.Parse("2006-01-02 15:04:05", combine)
			if err != nil {
				fmt.Println("Error parsing input as time:", err)
				return
			}

			trip.StartTravelingTime = parsedTime
			fmt.Println("Parsed time:", parsedTime)

			fmt.Print("Enter Destination Address: ")
			_, err = fmt.Scan(&trip.DestinationAddress)
			if err != nil {
				fmt.Println("Error reading Destination Address:", err)
				continue
			}

			fmt.Print("Enter Available Seats: ")
			_, err = fmt.Scan(&trip.AvailableSeats)
			if err != nil {
				fmt.Println("Error reading Available Seats:", err)
				continue
			}

			// Convert trip data to JSON
			payload, err := json.Marshal(trip)
			if err != nil {
				fmt.Println("Error marshaling trip data to JSON:", err)
				continue
			}

			// Send a POST request to the CreateTrip API
			url := "http://localhost:8080/trips" // Replace with the actual API endpoint URL
			resp, err := http.Post(url, "application/json", bytes.NewBuffer(payload))
			if err != nil {
				fmt.Println("Error sending HTTP request:", err)
				continue
			}
			defer resp.Body.Close()

			// Check the response status code
			if resp.StatusCode == http.StatusOK {
				fmt.Println("Car-pooling trip published successfully!")
			} else {
				fmt.Println("Error publishing car-pooling trip. Status code:", resp.StatusCode)
			}

		case 3:
			type TripsResponse struct {
				Trips []models.Trip `json:"trips"`
			}
			url := "http://localhost:8080/alltrips" // Replace with the actual API endpoint URL
			resp, err := http.Get(url)
			if err != nil {
				fmt.Println("Error sending HTTP request:", err)
				continue
			}
			body, err := ioutil.ReadAll(resp.Body)
			if err != nil {
				fmt.Println("Error reading response body:", err)
				return
			}
			var tripsResponse TripsResponse
			err1 := json.Unmarshal([]byte(body), &tripsResponse)
			if err1 != nil {
				fmt.Println("Error unmarshaling JSON:", err)
				return
			}

			// Print the formatted list of trips
			for i, trip := range tripsResponse.Trips {
				fmt.Printf("Trip %d:\n", i+1)
				fmt.Printf("ID: %d\n", trip.ID)
				fmt.Printf("Car Owner Email: %s\n", trip.CarOwnerEmail)
				fmt.Printf("Pickup Location: %s\n", trip.PickupLocation)
				fmt.Printf("Alt Pickup Locations: %s\n", trip.AltPickupLocations)
				fmt.Printf("Start Traveling Time: %s\n", trip.StartTravelingTime)
				fmt.Printf("Destination Address: %s\n", trip.DestinationAddress)
				fmt.Printf("Available Seats: %d\n", trip.AvailableSeats)
				fmt.Printf("Trip Status: %s\n", trip.TripStatus)
				fmt.Printf("Scheduled Start Time: %s\n", trip.ScheduledStartTime)
				fmt.Println("------------------------------------------------------------")
				fmt.Println()
			}
			// Convert the response body to a string and print it

			defer resp.Body.Close()

			var enroll models.Enrollment
			fmt.Print("Enter trip Id to Enroll: ") 
			_, err2 := fmt.Scan(&enroll.TripID)
			if err2 != nil {
				fmt.Println("Error reading input:", err)
				return
			}
			enroll.PassengerEmail = userEmail

			payload, err := json.Marshal(enroll)
			if err != nil {
				fmt.Println("Error marshaling trip data to JSON:", err)
				continue
			}

			url1 := "http://localhost:8080/enroll" // Replace with the actual API endpoint URL
			resp1, err := http.Post(url1, "application/json", bytes.NewBuffer(payload))
			if err != nil {
				fmt.Println("Error sending HTTP request:", err)
				continue
			}
			defer resp1.Body.Close()

		case 4:
			type TripsResponse struct {
				Trips []models.Trip `json:"trips"`
			}

			var trip models.Trip

			trip.CarOwnerEmail = userEmail

			payload, err := json.Marshal(trip)
			if err != nil {
				fmt.Println("Error marshaling trip data to JSON:", err)
				continue
			}

			url1 := "http://localhost:8080/mytrips" // Replace with the actual API endpoint URL
			resp, err := http.Post(url1, "application/json", bytes.NewBuffer(payload))
			if err != nil {
				fmt.Println("Error sending HTTP request:", err)
				continue
			}

			if err != nil {
				fmt.Println("Error sending HTTP request:", err)
				continue
			}
			body, err := ioutil.ReadAll(resp.Body)
			if err != nil {
				fmt.Println("Error reading response body:", err)
				return
			}
			var tripsResponse TripsResponse
			err1 := json.Unmarshal([]byte(body), &tripsResponse)
			if err1 != nil {
				fmt.Println("Error unmarshaling JSON:", err)
				return
			}

			// Print the formatted list of trips
			for i, trip := range tripsResponse.Trips {
				fmt.Printf("Trip %d:\n", i+1)
				fmt.Printf("ID: %d\n", trip.ID)
				fmt.Printf("Car Owner Email: %s\n", trip.CarOwnerEmail)
				fmt.Printf("Pickup Location: %s\n", trip.PickupLocation)
				fmt.Printf("Alt Pickup Locations: %s\n", trip.AltPickupLocations)
				fmt.Printf("Start Traveling Time: %s\n", trip.StartTravelingTime)
				fmt.Printf("Destination Address: %s\n", trip.DestinationAddress)
				fmt.Printf("Available Seats: %d\n", trip.AvailableSeats)
				fmt.Printf("Trip Status: %s\n", trip.TripStatus)
				fmt.Printf("Scheduled Start Time: %s\n", trip.ScheduledStartTime)
				fmt.Println("------------------------------------------------------------")
				fmt.Println()
			}
			// Convert the response body to a string and print it

			defer resp.Body.Close()

			var trip1 models.Trip
			fmt.Print("Enter trip Id to Cancel: ")
			_, err2 := fmt.Scan(&trip1.ID)
			if err2 != nil {
				fmt.Println("Error reading input:", err)
				return
			}

			payload1, err := json.Marshal(trip1)
			if err != nil {
				fmt.Println("Error marshaling trip data to JSON:", err)
				continue
			}
			url2 := "http://localhost:8080/delete" // Replace with the actual API endpoint URL
			resp1, err := http.Post(url2, "application/json", bytes.NewBuffer(payload1))
			if err != nil {
				fmt.Println("Error sending HTTP request:", err)
				continue
			}
			defer resp1.Body.Close()

		case 5:
			// Exit the application.
			fmt.Println("Exiting the Car-Pooling Platform Console App.")
			os.Exit(0)
		default:
			fmt.Println("Invalid choice. Please select a valid option.")
		}
	}

}
