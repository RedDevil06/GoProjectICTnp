
/* CREATE USER 'user'@'localhost' IDENTIFIED BY '12345';​ 

GRANT ALL ON *.* TO 'user'@'localhost';

CREATE database carpool;

use carpool;
CREATE TABLE users (
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    mobile_number VARCHAR(15) NOT NULL,
    email VARCHAR(100) PRIMARY KEY NOT NULL ,
    password_hash VARCHAR(100) NOT NULL,
    driver_license_number VARCHAR(20),
    car_plate_number VARCHAR(20),
    user_type ENUM('passenger', 'car_owner')
);


CREATE TABLE trips (
    id INT AUTO_INCREMENT PRIMARY KEY,
    car_owner_email VARCHAR(100) NOT NULL,
    pickup_location TEXT NOT NULL,
    alt_pickup_locations TEXT,
    start_traveling_time DATETIME NOT NULL,
    destination_address TEXT NOT NULL,8
    available_seats INT NOT NULL,
    trip_status ENUM('published', 'in-progress', 'completed', 'canceled') NOT NULL,
    scheduled_start_time DATETIME,
    creation_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (car_owner_email) REFERENCES users(email)
);



CREATE TABLE enrollments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    trip_id INT NOT NULL,
    passenger_email VARCHAR(100) NOT NULL,
    enrollment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (trip_id) REFERENCES trips(id),
    FOREIGN KEY (passenger_email) REFERENCES users(email)
);
*/