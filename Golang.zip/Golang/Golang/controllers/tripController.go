package controllers

import (
	"GOLANG/models"
	"GOLANG/services"
	"encoding/json"
	"net/http"

	"github.com/gin-gonic/gin"
)

// CreateTrip handles the creation of a new trip.
func CreateTrip(w http.ResponseWriter, r *http.Request) {
	var trip models.Trip
	err := json.NewDecoder(r.Body).Decode(&trip)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	response, err := services.CreateTrip(trip)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(gin.H{"user": response})
}

// DeleteTrip handles the deletion of a trip.
func DeleteTrip(w http.ResponseWriter, r *http.Request) {
	var trip models.Trip
	err := json.NewDecoder(r.Body).Decode(&trip)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	response, err := services.DeleteTrip(trip)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(gin.H{"user": response})
}

// EnrollmentInTrip handles the enrollment of a user in a trip.
func EnrollmentInTrip(w http.ResponseWriter, r *http.Request) {
	var enrollment models.Enrollment
	err := json.NewDecoder(r.Body).Decode(&enrollment)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	response, err := services.CreateEnrollment(enrollment)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(gin.H{"user": response})
}

// AllTrips retrieves a list of all trips.
func AllTrips(w http.ResponseWriter, r *http.Request) {
	response, err := services.AllTrips()
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(gin.H{"trips": response})
}

// MyTrips retrieves a list of trips associated with a specific user.
func MyTrips(w http.ResponseWriter, r *http.Request) {
	var trip models.Trip
	err := json.NewDecoder(r.Body).Decode(&trip)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	response, err := services.MyTrips(trip)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(gin.H{"trips": response})
}
