# Car-Pooling Platform Console App

Design Considerations for Microservices:->>>>>>>>>>>>>>

1. Bounded Context:

Each service represent a bounded context, focusing on a specific domain and functionality. This promotes autonomy, maintainability, and scalability.
"Services" package focuses on trip management while the other package manages user data. This is a good starting point, but further refinement might be needed.

2. Single Responsibility Principle:

Each function within a service have a single, well-defined responsibility. This makes the code easier to understand, test, and maintain.
For example, CreateTrip and DeleteTrip seem well-aligned with the single responsibility principle.

3. Data Ownership:

Each service own and manage its own data. This avoids data duplication and inconsistencies. Thus assigning ownership based on domain logic and dependencies.

4. Communication and APIs:

Services communicate with each other through well-defined APIs, often using protocols like HTTP or gRPC.
My code is able to design APIs for user management and trip-related information exchange.

5. Technology Stack:

Choose's technologies that are well-suited for microservices development, such as containerization (Docker/Kubernetes) and service discovery tools.

6. Testing and Monitoring:

Each service is able to independently testable and have comprehensive monitoring systems to track performance and health.

7. Observability and Logging:

Implement detailed logging and tracing mechanisms to understand how services interact and troubleshoot issues.
There is incorporating tracing and logging which can be beneficial for debugging and performance analysis.

Additional Considerations:

Event-driven Architecture: Considered using event-driven communication for asynchronous communication between services.
Resilience and Fault Tolerance: Design services to be resilient to failures and handle errors gracefully.
Configuration Management: Use a centralized configuration management system to manage configuration across all services.

Architecture Diagram in ASCII:
                    +------------------+
                    |   Frontend/API   |
                    +------------------+
                        |  Request  |
                        | (HTTP)    |
                        |----------|
                        |         |
                        |         v
                    +------------------+
                    |   main.go (ResAPI)|
                    +------------------+
                        |  Handles Request |
                        |                 |
                        |----------------|
                        |       /       |
                        |      /        |
                        |     /         |
                   +-----------------+      +-------------------+
                   | UserController   |      | TripController   |
                   +-----------------+      +-------------------+
                        |  Calls Service |      |  Calls Service |
                        |                 |      |                 |
                        |----------------|      |-----------------|
                        |       /       |      |       /       |
                        |      /        |      |      /        |
                        |     /         |      |     /         |
                   +-----------------+      +-------------------+
                   | UserService    |      | TripService     |
                   +-----------------+      +-------------------+

                   +---------+         +---------+
                   | Database |         | Database |
                   +---------+         +---------+

Key:

Frontend/API: This represents the external interface, like a web API, that interacts with the system.
main.go (ResAPI): This is the entry point for the backend service, written in Go.
Request: This is the incoming data from the user, such as an HTTP request.
UserController: This controller handles all requests related to users.
TripController: This controller handles all requests related to trips.
UserService: This service handles all logic related to users, including data access, validation, and business rules.
TripService: This service handles all logic related to trips, including data access, validation, and business rules.
Database: This represents the persistent storage for the application data.

Explanation:

The user interacts with the Frontend/API, which sends an HTTP request to the backend.
The main.go (ResAPI) receives the request, parses it, and routes it to the appropriate controller based on the URL or other factors.
The UserController or TripController handles the request, performs any necessary validation and business logic, and calls the appropriate service.
The UserService or TripService performs the requested operation on the data, retrieves the results, and returns them to the controller.
The controller formats the results and sends them back to the Frontend/API.
The Frontend/API receives the response and displays it to the user.

The Car-Pooling Platform Console App is a command-line application that allows users to interact with the Car-Pooling platform through various actions, such as creating user accounts, signing in, registering trips, enrolling in trips, and more.

## Getting Started


//Instructions of setting up and running the microservices


Before running the Car-Pooling Platform Console App, have GoLang and required dependencies installed on system.

### Prerequisites

- GoLang: [Download and Install Go](https://golang.org/dl/)

### Installation

- go run  main.go


Sign In
To sign in, select option 0 and provide your email and password hash when prompted. This will authenticate you as a user.

Create User Account/Sign Up
To create a new user account, select option 1 and provide the required user information, including first name, last name, mobile number, email, and password hash. Upon successful creation, you will receive a confirmation.

Register a Trip
If you are a car owner (user type 2), you can register a car-pooling trip by selecting option 2. Provide the trip details, including the car owner's email, pickup location, alternate pickup locations (optional), start traveling date, start traveling time, destination address, and available seats. Your trip will be registered on the platform.

Enroll In a Trip
Users (both passengers and car owners) can enroll in trips by selecting option 3. Enter the trip ID to enroll in the desired trip. Your enrollment will be confirmed upon success.

Delete a Trip
If you are a car owner (user type 2), you can delete your registered trips by selecting option 4. Enter the trip ID to delete the specific trip.

Exit
To exit the application, select option 5.





